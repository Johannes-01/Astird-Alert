﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AstridAlert
{
    public static class Constants
    {
        //windows message id for hotkey
        public const int WM_HOTKEY_MSG_ID = 0x0312;
    }
}
